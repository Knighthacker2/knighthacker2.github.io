# Orlando Torres — Portfolio Site

A single-page mechanical engineering portfolio, built as a self-contained HTML file (blueprint / technical-drawing style).

## Deploy on GitHub Pages

1. Create a new repo named exactly `yourusername.github.io` (replace with your GitHub username).
2. Upload `index.html` to the root of the repo.
3. Go to **Settings → Pages**, set Source to "Deploy from a branch", branch `main`, folder `/ (root)`, then Save.
4. Your site will be live at `https://yourusername.github.io` within a minute or two.

## Customize

Open `index.html` in any text editor and edit:
- Name, school, class year, and contact info near the top
- Experience table rows
- Project cards
- Skills list

No build step or dependencies — it's plain HTML/CSS with fonts loaded from Google Fonts.
